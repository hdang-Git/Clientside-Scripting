package model.Planet;

public class StringData {

    // select country_id, country_name, flag_abbrev, flag_URL from country_flag
    public String planetId = "";
    public String planetName = "";
    public String planetSize = "";
    public String dateDiscovered = "";
    public String planetDescrip = "";
    public String planetURL = "";
    public String errorMsg = "";
}

