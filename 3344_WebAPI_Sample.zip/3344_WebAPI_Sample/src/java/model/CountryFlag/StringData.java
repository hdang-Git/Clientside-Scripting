package model.CountryFlag;

public class StringData {

    // select country_id, country_name, flag_abbrev, flag_URL from country_flag
    public String countryId = "";
    public String countryName = "";
    public String flagAbbrev = "";
    public String flagURL = "";
    public String errorMsg = "";
}